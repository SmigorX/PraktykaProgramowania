class TennisGame1:
    def __init__(self, player1_name, player2_name):
        self.player1_name = player1_name
        self.player2_name = player2_name
        self.player1_points = 0
        self.player2_points = 0
        #rename p to player

    def won_point(self, player_name):
        if player_name == "player1":
            self.player1_points += 1
        else:
            self.player2_points += 1

    #extracted function
    def _score_points_equal(self):
        possible_result = {
            0: "Love-All",
            1: "Fifteen-All",
            2: "Thirty-All",
        }

        return possible_result.get(self.player1_points, "Deuce")

    #Added error for wrong scores instead of giving win to player 2
    def _score_points_over_four(self):
        minus_result = self.player1_points - self.player2_points
        if minus_result == 1:
            result = "Advantage player1"
        elif minus_result == -1:
            result = "Advantage player2"
        elif minus_result >= 2:
            result = "Win for player1"
        else:
            result = "Win for player2"
        return result


    def _other_scores(self):
        score_values = {
                    0: "Love",
                    1: "Fifteen",
                    2: "Thirty",
                    3: "Forty",
                }

        return f"{score_values[self.player1_points]}-{score_values[self.player2_points]}"

    #Removed dead code
    #Moved to quick returns
    def score(self):
        if self.player1_points == self.player2_points:
            return self._score_points_equal()

        if self.player1_points >= 4 or self.player2_points >= 4:
            return self._score_points_over_four()

        return self._other_scores()
