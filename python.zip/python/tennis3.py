class TennisGame3:
    def __init__(self, player1_name, player2_name):
        self.player1_name = player1_name
        self.player2_name = player2_name
        self.player1_score = 0
        self.player2_score = 0

    def won_point(self, n):
        if n == "player1":
            self.player1_score += 1
        else:
            self.player2_score += 1

    #changed var names
    def score(self):
        #extracted possible scores
        possible_scores = ["Love", "Fifteen", "Thirty", "Forty"]

        if (self.player1_score < 4 and self.player2_score < 4) and (self.player1_score + self.player2_score < 6):
            player1_score = possible_scores[self.player1_score]
            #Extracted ternary operator
            if self.player1_score == self.player2_score:
                return player1_score + "-All"
            else:
                return player1_score + "-" + possible_scores[self.player2_score]

        else:
            if self.player1_score == self.player2_score:
                return "Deuce"
            player1_score = self.player1_name if self.player1_score > self.player2_score else self.player2_name
            return (
                "Advantage " + player1_score
                if ((self.player1_score - self.player2_score) * (self.player1_score - self.player2_score) == 1)
                else "Win for " + player1_score
            )
