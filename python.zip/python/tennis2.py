class TennisGame2:
    def __init__(self, player1_name, player2_name):
        self.player1_name = player1_name
        self.player2_name = player2_name
        self.player1_points = 0
        self.player2_points = 0

    def won_point(self, player_name):
        if player_name == "player1":
            self.player1_points += 1
        else:
            self.player2_points += 1

    def score(self):
        #Moved score mapping
        score_values = {
            0: "Love",
            1: "Fifteen",
            2: "Thirty",
            3: "Forty"
        }
        if self.player1_points == self.player2_points and self.player1_points < 3:
            return score_values[self.player1_points] + "-All"

        if self.player1_points == self.player2_points and self.player1_points > 2:
            return "Deuce"

        if (
            self.player1_points >= 4
            and self.player2_points >= 0
            and (self.player1_points - self.player2_points) >= 2
        ):
            return "Win for player1"
        if (
            self.player2_points >= 4
            and self.player1_points >= 0
            and (self.player2_points - self.player1_points) >= 2
        ):
            return "Win for player2"

        if self.player1_points > self.player2_points and self.player2_points >= 3:
            return "Advantage player1"

        if self.player2_points > self.player1_points and self.player1_points >= 3:
            return "Advantage player2"

        return score_values[self.player1_points] + "-" + score_values[self.player2_points]

    #Removed the if hell

    #Removed redundant functions
